# !/usr/bin/python
# -*- coding: cp1252 -*-
#
##################################################################################
#
#    This program is part of OSRFramework. You can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##################################################################################

"""
    NOTE: you will have to rename this file to config_credentials.py to let the library open the credentials.
"""

def returnListOfCreds():
    '''
        :return: A list of tuples containing in the first the name of the platform
    '''
    listCreds = []
    #listCreds.append(("<platform>", "<username>", "<password>"))
    #
    # The platforms that need a username and password are the following. 
    # Uncomment the lines and change the <user> and <pass>.
    #
    #listCreds.append(("eqe", "<username>", "<password>"))    
    #listCreds.append(("flixter", "<username>", "<password>"))  
    #listCreds.append(("pokerstrategy", "<username>", "<password>"))    
    #listCreds.append(("rapid", "<username>", "<password>"))    
    #listCreds.append(("researchgate", "<username>", "<password>"))        
    #listCreds.append(("spotify", "<username>", "<password>"))            
    #listCreds.append(("tripit", "<username>", "<password>"))
    #listCreds.append(("wordreference", "<username>", "<password>"))
    return listCreds
